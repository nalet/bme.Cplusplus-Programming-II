#ifndef CONSTRAINT_H
#define CONSTRAINT_H

#include <vector>
#include <array>
#include "vtkPolyData.h"
#include "planning/layer.h"
#include "vtkPolyDataConnectivityFilter.h"
#include "vtkCenterOfMass.h"
#include "vtkExtractSelectedThresholds.h"
#include "vtkExtractSelection.h"
#include "vtkFeatureEdges.h"
#include <array>
#include "vtkSphereSource.h"
#include "vtkLineSource.h"
#include "vtkTubeFilter.h"
#include "vtkTriangleFilter.h"
#include "vtkIntersectionPolyDataFilter.h"
#include <tuple>
#include <future>

namespace planning::layer
{
class ImageLayer;
}

namespace planning::constraint
{

class TumorTrajectory
{
public:
    TumorTrajectory(std::array<float, 3> vector, vtkSmartPointer<vtkPolyData> polyData);
    std::array<float, 3> vector;
    vtkSmartPointer<vtkPolyData> polyData;
    vtkSmartPointer<vtkDataArray> intersectionPoints;
};

class TumorPlan
{
public:
    TumorPlan() {}
    TumorPlan(std::array<float, 3> centroid, std::shared_ptr<std::vector<TumorTrajectory>> trajectories);
    std::array<float, 3> centroid;
    std::shared_ptr<std::vector<TumorTrajectory>> trajectories;
};

std::vector<std::array<float, 3>> extract_tumor_centroids(std::shared_ptr<planning::layer::ImageLayer> liverTumorLayer);
std::shared_ptr<std::vector<planning::constraint::TumorPlan>> generateTrajectories(std::vector<std::array<float, 3>> liverTumorCentroids, int trajectoryDetail, int needleLength);
std::vector<std::array<float, 3>> generateTrajectoriesCandidatesPoints(std::array<float, 3> centroid, int trajectoryDetail, int needleLength);
vtkSmartPointer<vtkPolyData> create_single_poly_data_line(std::array<float, 3> line_point, std::array<float, 3> center);
std::shared_ptr<std::vector<planning::constraint::TumorPlan>> check_trajectories_candidates(std::shared_ptr<std::vector<planning::constraint::TumorPlan>> tumorPlans, std::shared_ptr<std::vector<planning::layer::ImageLayer>> layers, vtkSmartPointer<vtkPolyData> hard_constraint_poly_data);
std::tuple<bool, vtkDataArray *> check_against_constraints(vtkSmartPointer<vtkPolyData> trajectory, vtkTriangleFilter * hard_constraint_triangle);

}
#endif // CONSTRAINT_H
