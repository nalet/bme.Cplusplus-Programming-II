#ifndef UTILS_H
#define UTILS_H


class Utils
{
public:
    Utils();
};

#endif // UTILS_H
