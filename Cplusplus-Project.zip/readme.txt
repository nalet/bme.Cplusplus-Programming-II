1) Open the CMakeLists.txt in the native folder
2) Set the VTK_DIR Variable to your VTK build folder.
3) Start the Project
4) Select the directory "3Dircadb1.04" in the folder data and click open
5) Close the Render Window to get to the next step
   The filtering of the Intersection takes several minutes and is not multi threading capable.

HINT: "vtkPolyDataReader* reader = vtkPolyDataReader::New();" is a raw pointer. This is ment to be this way, as the smart pointer from the VTK library are scope sensitive. When the filter/loader is deleted, so is the data.