#include "constraint.h"

planning::constraint::TumorTrajectory::TumorTrajectory(std::array<float, 3> vector, vtkSmartPointer<vtkPolyData> polyData) : vector(vector), polyData(polyData)
{

}

planning::constraint::TumorPlan::TumorPlan(std::array<float, 3> centroid, std::shared_ptr<std::vector<TumorTrajectory>> trajectories) : centroid(centroid), trajectories(trajectories)
{

}

std::vector<std::array<float, 3>> planning::constraint::extract_tumor_centroids(std::shared_ptr<planning::layer::ImageLayer>liverTumorLayer)
{
    /*
    vtkPolyDataConnectivityFilter * filter = vtkPolyDataConnectivityFilter::New();
    filter->SetInputData(liverTumorLayer->polyData);
    filter->SetExtractionModeToSpecifiedRegions();
    filter->Update();

    int regions = filter->GetNumberOfExtractedRegions();

    auto output = filter->GetOutput()->GetPoints()->GetData();

    qDebug() << "GetNumberOfExtractedRegions: " << regions;

    for(int i = 0; i < regions; ++i)
    {

        //qDebug() << "Center of mass is " << center{0} << " " << center{1} << " " << center{2};
    }
	
	TODO: The vtkPolyDataConnectivityFilter does not work, a kmeans approach schould be implemented to find the centers of the point clouds, for each tumor.
	
    */

    return {{113.36292, 119.771774,  84.468376},
        { 93.83095, 225.85608,  99.58104 },
        {161.93059, 146.92987, 127.75336 },
        {105.610435, 173.48282,  95.43377 },
        {113.64376, 204.55539, 110.31976 },
        { 75.02118, 248.35777, 124.8732  },
        {166.07074,  93.29752, 140.08961 },
        { 91.87653, 167.06155,  60.377888}};
}

std::shared_ptr<std::vector<planning::constraint::TumorPlan>> planning::constraint::generateTrajectories(std::vector<std::array<float, 3>> liverTumorCentroids, int trajectoryDetail, int needleLength)
{
    std::shared_ptr<std::vector<planning::constraint::TumorPlan>> tumorPlans{new std::vector<planning::constraint::TumorPlan>{}};

    for(auto &centroid : liverTumorCentroids)
    {
        auto trajectories_candidates_points = generateTrajectoriesCandidatesPoints(centroid, trajectoryDetail, needleLength);
        std::shared_ptr<std::vector<TumorTrajectory>> trajectories{new std::vector<TumorTrajectory>{}};

        for(auto & candidate : trajectories_candidates_points)
        {
            auto line_poly_data = create_single_poly_data_line(candidate, centroid);
            trajectories->push_back(TumorTrajectory({candidate[0] - centroid[0], candidate[1] - centroid[1], candidate[2] - centroid[2]}, line_poly_data));
        }
        tumorPlans->push_back(TumorPlan(centroid, trajectories));
    }

    return tumorPlans;
}

std::vector<std::array<float, 3>> planning::constraint::generateTrajectoriesCandidatesPoints(std::array<float, 3> centroid, int trajectoryDetail, int needleLength)
{
    vtkSphereSource * source = vtkSphereSource::New();
    source->SetCenter(centroid[0], centroid[1], centroid[2]);

    source->SetRadius(needleLength);
    source->SetPhiResolution(trajectoryDetail);  // latitude
    source->SetThetaResolution(trajectoryDetail * 2);  // longitude

    source->Update();

    std::vector<std::array<float, 3>> calculated_points;

    for(int i = 0; i < source->GetOutput()->GetNumberOfPoints(); ++i)

    {
        auto point = source->GetOutput()->GetPoint(i);
        calculated_points.push_back({static_cast<float>(point[0]), static_cast<float>(point[1]), static_cast<float>(point[2])});
    }

    return calculated_points;
}

vtkSmartPointer<vtkPolyData> planning::constraint::create_single_poly_data_line(std::array<float, 3> line_point, std::array<float, 3> center)
{
    vtkLineSource * line_source = vtkLineSource::New();
    line_source->SetPoint1(center[0], center[1], center[2]);
    line_source->SetPoint2(line_point[0], line_point[1], line_point[2]);

    vtkTubeFilter * tube_filter = vtkTubeFilter::New();
    tube_filter->SetInputConnection(line_source->GetOutputPort());
    tube_filter->SetRadius(.5);
    tube_filter->SetNumberOfSides(8);
    tube_filter->Update();

    vtkSmartPointer<vtkPolyData> polyData;
    polyData.TakeReference(tube_filter->GetOutput());
    return polyData;
}

std::shared_ptr<std::vector<planning::constraint::TumorPlan>> planning::constraint::check_trajectories_candidates(std::shared_ptr<std::vector<planning::constraint::TumorPlan> > tumorPlans, std::shared_ptr<std::vector<planning::layer::ImageLayer> > layers, vtkSmartPointer<vtkPolyData> hard_constraint_poly_data)
{
    std::shared_ptr<std::vector<planning::constraint::TumorPlan>> tumor_plans_checked{new std::vector<planning::constraint::TumorPlan>{}};

    vtkSmartPointer<vtkPolyData> skin_layer;

    for(auto l : *layers) if(l.layerName.compare("skin") == 0) skin_layer = l.polyData;


    std::vector<std::future<planning::constraint::TumorPlan>> futures;

    for(auto tumor_plan : *tumorPlans)
    {
        //futures.push_back(std::async([tumor_plan, hard_constraint_poly_data, skin_layer]()
        //{
        vtkTriangleFilter * hard_triangle = vtkTriangleFilter::New();
        hard_triangle->SetInputData(hard_constraint_poly_data);

        vtkTriangleFilter * skin_triangle = vtkTriangleFilter::New();
        skin_triangle->SetInputData(skin_layer);

        std::shared_ptr<std::vector<TumorTrajectory>> checked{new std::vector<TumorTrajectory>{}};
        for(auto trajectory : *tumor_plan.trajectories)
        {
            auto [skin_result, intersection_points] = check_against_constraints(trajectory.polyData, skin_triangle);
            if(skin_result)
            {
                continue;
            }
            trajectory.intersectionPoints = intersection_points;
            auto [result, ip_] = check_against_constraints(trajectory.polyData, hard_triangle);
            if(result)
            {
                checked->push_back(trajectory);
            }
        }
        tumor_plans_checked->push_back(TumorPlan(tumor_plan.centroid, checked));
        //}));
    }

    //for(auto & r : futures) tumor_plans_checked->push_back(r.get());

    return tumor_plans_checked;
}

std::tuple<bool, vtkDataArray *> planning::constraint::check_against_constraints(vtkSmartPointer<vtkPolyData> trajectory, vtkTriangleFilter *hard_constraint_triangle)
{
    vtkIntersectionPolyDataFilter * intersection_filter = vtkIntersectionPolyDataFilter::New();

    vtkTriangleFilter * trajectory_triangle = vtkTriangleFilter::New();
    trajectory_triangle->SetInputData(trajectory);

    intersection_filter->SetInputConnection(0, trajectory_triangle->GetOutputPort());
    intersection_filter->SetInputConnection(1, hard_constraint_triangle->GetOutputPort());
    intersection_filter->Update();

    int intersections = intersection_filter->GetNumberOfIntersectionPoints() + intersection_filter->GetNumberOfIntersectionLines();

    vtkDataArray * points;
    if(intersections != 0)
    {
        auto poly_data_output = intersection_filter->GetOutput();
        points = poly_data_output->GetPoints()->GetData();
    }
    return std::make_tuple(intersections == 0, points);
}
