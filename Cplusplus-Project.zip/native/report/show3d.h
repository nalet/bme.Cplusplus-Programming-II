#ifndef SHOW3D_H
#define SHOW3D_H

#include "loader/loader.h"
#include "planning/layer.h"
#include "vtkActor.h"
#include "vtkRenderer.h"
#include "vtkPolyDataMapper.h"
#include "vtkProperty.h"
#include "vtkRenderWindow.h"
#include "vtkRenderWindowInteractor.h"
#include <QDebug>

namespace report
{

vtkSmartPointer<vtkActor> getActorFromImageLayer(planning::layer::ImageLayer imageLayer);
void show3d(std::shared_ptr<std::vector<planning::layer::ImageLayer>> imageLayers);

}

#endif // SHOW3D_H
