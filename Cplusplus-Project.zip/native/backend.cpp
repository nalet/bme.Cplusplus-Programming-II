#include "backend.h"


Backend::Backend(QObject *parent) :
    QObject(parent)
{

}

void Backend::load(QUrl url)
{
    qDebug() << url.toString();

    auto data = loader::load(url);

    this->planner = planner::plan(data);

}
