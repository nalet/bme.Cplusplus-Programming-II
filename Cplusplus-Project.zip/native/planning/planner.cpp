#include "planner.h"

planner::Planner::Planner(std::shared_ptr<loader::PatientData> patientData, int trajectoryDetail, int needleLength, std::array<float, 3> unitVector) : patientData(patientData), trajectoryDetail(trajectoryDetail), needleLength(needleLength), unitVector(unitVector)
{
    vtkObject::GlobalWarningDisplayOff();
}

void planner::Planner::planAllStepsAndShowResults()
{
    this->prepareLayers();
    //this->showResults();
    this->calculateTumorCentroids();
    this->showResults();
    this->generateCandidates();
    this->showResults();
    this->calculateHardConstraints();
    this->checkAgainstConstraints();
    this->showResults();
}

std::shared_ptr<planner::Planner> planner::plan(std::shared_ptr<loader::PatientData> patientData, int trajectoryDetail, int needleLength, std::array<float, 3> unitVector)
{
    std::shared_ptr<Planner> planner{new Planner(patientData, trajectoryDetail, needleLength, unitVector)};
    planner->planAllStepsAndShowResults();
    return planner;
}

void planner::Planner::prepareLayers()
{
    this->layers = planning::layer::prepareLayers(this->patientData->vtk);
}

void planner::Planner::calculateTumorCentroids()
{
    for(const auto l : *this->layers) if(l.layerName.compare("livertumor")) this->liverTumorLayer = std::make_shared<planning::layer::ImageLayer>(l);
    this->liverTumorCentroids = planning::constraint::extract_tumor_centroids(this->liverTumorLayer);
    auto centroids = planning::layer::createPointsLayer(this->liverTumorCentroids);
    this->layers->push_back(planning::layer::createLayer(centroids, "centroid"));
}

void planner::Planner::generateCandidates()
{
    this->tumorPlans = planning::constraint::generateTrajectories(this->liverTumorCentroids, this->trajectoryDetail, this->needleLength);
    planning::layer::updateLayerWithTrajectories(this->layers, this->tumorPlans);

    this->foundTumorsCount = this->tumorPlans->size();
    if(this->foundTumorsCount > 0) this->plannedTrajectoriesEachTumor = this->tumorPlans->at(0).trajectories->size();
}

void planner::Planner::calculateHardConstraints()
{
    this->hardConstraintLayer = planning::layer::create_hard_constraint_layer(this->layers);
}

void planner::Planner::checkAgainstConstraints()
{
    this->tumorPlans = planning::constraint::check_trajectories_candidates(this->tumorPlans, this->layers, this->hardConstraintLayer->at(0).polyData);
    planning::layer::updateLayerWithTrajectories(this->layers, this->tumorPlans);
}

void planner::Planner::showResults()
{
    report::show3d(this->layers);
}
