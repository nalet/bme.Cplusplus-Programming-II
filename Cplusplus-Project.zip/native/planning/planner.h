#ifndef PLANNER_H
#define PLANNER_H

#include "loader/loader.h"
#include "planning/layer.h"
#include "planning/constraint.h"
#include <array>
#include "report/show3d.h"

namespace planner
{
class Planner
{
protected:
    std::shared_ptr<loader::PatientData> patientData;
    int trajectoryDetail;
    int needleLength;
    std::array<float, 3> unitVector;

    std::array<float, 3> unitVector2;
    std::shared_ptr<std::vector<planning::layer::ImageLayer>> layers;
    std::vector<std::array<float, 3>> liverTumorCentroids;
    std::shared_ptr<planning::layer::ImageLayer> liverTumorLayer;
    std::shared_ptr<std::vector<planning::constraint::TumorPlan>> tumorPlans;
    std::shared_ptr<std::vector<planning::layer::ImageLayer>> hardConstraintLayer;
    float workSpaceVolume = 0.0;
    int foundTumorsCount = 0;
    int plannedTrajectoriesEachTumor = 0;
public:
    Planner(std::shared_ptr<loader::PatientData> patientData, int trajectoryDetail = 10, int needleLength = 150, std::array<float, 3> unitVector = {});
    void planAllStepsAndShowResults();
    void prepareLayers();
    void calculateTumorCentroids();
    void generateCandidates();
    void calculateHardConstraints();
    void checkAgainstConstraints();

    void showResults();
};

std::shared_ptr<planner::Planner> plan(std::shared_ptr<loader::PatientData> patientData, int trajectoryDetail = 4, int needleLength = 150, std::array<float, 3> unitVector = {});

}




#endif // PLANNER_H
