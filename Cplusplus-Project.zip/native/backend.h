#ifndef BACKEND_H
#define BACKEND_H

#include <QObject>
#include <iostream>
#include <QUrl>
#include <QDebug>
#include "planning/planner.h"
#include "loader/loader.h"

class Backend : public QObject
{
    Q_OBJECT
protected:
    std::shared_ptr<planner::Planner> planner{};
public:
    explicit Backend(QObject *parent = nullptr);
    Q_INVOKABLE void load(QUrl url);
};

#endif // BACKEND_H
