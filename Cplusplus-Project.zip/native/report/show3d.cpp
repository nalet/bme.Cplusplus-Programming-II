#include "show3d.h"

vtkSmartPointer<vtkActor> report::getActorFromImageLayer(planning::layer::ImageLayer imageLayer)
{
    vtkPolyDataMapper* mapper = vtkPolyDataMapper::New();
    mapper->SetInputData(imageLayer.polyData);

    //qDebug() << imageLayer.polyData->GetNumberOfPoints();

    vtkActor * actor = vtkActor::New();
    actor->SetMapper(mapper);
    actor->GetProperty()->SetOpacity(.5);

    if(imageLayer.layerName.compare("liver")  == 0)
    {
        actor->GetProperty()->SetColor(1, 0, 0);  // R,G,B

    }
    if(imageLayer.layerName.compare("livertumor")  == 0)
    {
        actor->GetProperty()->SetColor(1, 1, 0);  // R,G,B

    }
    if(imageLayer.layerName.compare("centroid")  == 0)
    {
        actor->GetProperty()->SetColor(0, 0, 1);  // R,G,B
        actor->GetProperty()->SetOpacity(1);
        actor->GetProperty()->SetPointSize(20);
        actor->GetProperty()->RenderPointsAsSpheresOn();

    }
    if(imageLayer.layerName.compare("trajectories")  == 0)
    {
        actor->GetProperty()->SetColor(0, 0, 1) ; // R,G,B
        actor->GetProperty()->SetOpacity(1);
        actor->GetProperty()->SetLineWidth(4);

    }
    if(imageLayer.layerName.compare("mean_direction")  == 0)
    {
        actor->GetProperty()->SetColor(1, 0, 0) ; // R,G,B
        actor->GetProperty()->SetOpacity(1);
        actor->GetProperty()->SetLineWidth(8);

    }
    if(imageLayer.layerName.compare("mean_direction_2")  == 0)
    {
        actor->GetProperty()->SetColor(0, 1, 0);  // R,G,B
        actor->GetProperty()->SetOpacity(1);
        actor->GetProperty()->SetLineWidth(8);

    }
    if(imageLayer.layerName.compare("skin_trajectory")  == 0)
    {
        actor->GetProperty()->SetColor(1, 0.867, 0.933) ; // R,G,B
        actor->GetProperty()->SetOpacity(1);
        actor->GetProperty()->SetPointSize(10);
        actor->GetProperty()->RenderPointsAsSpheresOn();

    }
    if(imageLayer.layerName.compare("work_space")  == 0)
    {
        actor->GetProperty()->SetColor(0, 0, 1);  // R,G,B
        actor->GetProperty()->SetOpacity(0.4);
    }

    vtkSmartPointer<vtkActor> pActor;
    pActor.TakeReference(actor);
    return pActor;
}

void report::show3d(std::shared_ptr<std::vector<planning::layer::ImageLayer> > imageLayers)
{
    vtkSmartPointer<vtkRenderer> renderer = vtkSmartPointer<vtkRenderer>::New();

    for(const auto image_layer : *imageLayers)
    {
        auto actor = getActorFromImageLayer(image_layer);
        renderer->AddActor(actor);
    }

    renderer->SetBackground(.5, .5, .5);

    vtkSmartPointer<vtkRenderWindow> renderWindow = vtkSmartPointer<vtkRenderWindow>::New();

    renderWindow->AddRenderer(renderer);
    vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor = vtkSmartPointer<vtkRenderWindowInteractor>::New();
    renderWindowInteractor->SetRenderWindow(renderWindow);
    renderWindow->Render();
    renderWindowInteractor->Start();
}
