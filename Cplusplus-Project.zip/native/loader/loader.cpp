#include "loader.h"


std::shared_ptr<loader::PatientData> loader::load(QUrl path)
{
    std::shared_ptr<PatientData> data{new PatientData{}};

    qDebug() << path.toLocalFile();

    for(const auto& entry : std::filesystem::directory_iterator(path.toLocalFile().toStdString()))
    {
        auto fileName = entry.path().filename().string();
        //qDebug() << QString::fromStdString(entry.path().filename().string());
        if(fileName.compare("patient.nii.gz") == 0)
        {
            data->patient = entry.path();
        }
        if(fileName.compare("segmentation.nii.gz") == 0)
        {
            data->segementation = entry.path();
        }
        if(fileName.compare("MESHES_VTK") == 0 && entry.is_directory())
        {
            for(const auto& vtk_entry : std::filesystem::directory_iterator(entry.path().string()))
            {
                data->vtk.push_back(vtk_entry.path());
            }
        }
    }
    return data;
}

vtkSmartPointer<vtkPolyData> loader::read_poly_data(std::filesystem::path path)
{
    std::string extension = path.extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(), ::tolower);
    vtkSmartPointer<vtkPolyData> polyData;

    if(extension.compare(".vtk") == 0)
    {
        vtkPolyDataReader* reader = vtkPolyDataReader::New();
        reader->SetFileName(path.string().c_str());
        reader->Update();
        polyData.TakeReference(reader->GetOutput());
    }

    return polyData;
}
