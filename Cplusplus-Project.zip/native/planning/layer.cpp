#include "layer.h"

planning::layer::ImageLayer::ImageLayer(std::string layerName, vtkSmartPointer<vtkPolyData> polyData) : layerName(layerName), polyData(polyData)
{

}

std::shared_ptr<std::vector<planning::layer::ImageLayer>> planning::layer::prepareLayers(std::vector<std::filesystem::path> layerFiles)
{
    std::shared_ptr<std::vector<planning::layer::ImageLayer>> layers{new std::vector<planning::layer::ImageLayer>};

    for(const auto & layerFile : layerFiles)
    {
        auto polyData = loader::read_poly_data(layerFile);
        auto layerName = layerFile.filename().string().substr(0, layerFile.filename().string().length() - layerFile.extension().string().length());
        layers->push_back(planning::layer::ImageLayer(layerName, polyData));

    }

    layers = consolidateLayers(layers);

    return layers;
}

std::shared_ptr<std::vector<planning::layer::ImageLayer>> planning::layer::consolidateLayers(const std::shared_ptr<std::vector<planning::layer::ImageLayer>> layers)
{
    std::shared_ptr<std::vector<planning::layer::ImageLayer>> consolidatedLayers{new std::vector<planning::layer::ImageLayer>};
    std::vector<std::string> layerNames;

    for(const auto &layer : *layers) layerNames.push_back(layer.layerName);
    std::sort(layerNames.begin(), layerNames.end());
    layerNames.erase(std::unique(layerNames.begin(), layerNames.end()), layerNames.end());

    for(const auto &name : layerNames)
    {
        vtkAppendPolyData * appendFilter = vtkAppendPolyData::New();
        for(const auto &layer : *layers)
        {
            if(layer.layerName.compare(name) == 0) appendFilter->AddInputData(layer.polyData);
        }
        appendFilter->Update();
        vtkSmartPointer<vtkPolyData> polyData;
        polyData.TakeReference(appendFilter->GetOutput());
        consolidatedLayers->push_back(planning::layer::ImageLayer(name, polyData));
    }


    return consolidatedLayers;
}

vtkSmartPointer<vtkPolyData> planning::layer::createPointsLayer(std::vector<std::array<float, 3>> pointList)
{
    vtkPoints * points = vtkPoints::New();

    vtkCellArray * vertices = vtkCellArray::New();

    for(auto &point_item : pointList)
    {
        auto new_point = points->InsertNextPoint(point_item[0], point_item[1], point_item[2]);
        vertices->InsertNextCell(1);
        vertices->InsertCellPoint(new_point);
    }
    vtkPolyData * points_poly_data = vtkPolyData::New();

    points_poly_data->SetPoints(points);
    points_poly_data->SetVerts(vertices);
    vtkSmartPointer<vtkPolyData> polyData;
    polyData.TakeReference(points_poly_data);
    return polyData;
}

planning::layer::ImageLayer planning::layer::createLayer(vtkSmartPointer<vtkPolyData> polyData, std::string layerName)
{
    return ImageLayer(layerName, polyData);
}

void planning::layer::updateLayerWithTrajectories(const std::shared_ptr<std::vector<planning::layer::ImageLayer>> layers, std::shared_ptr<std::vector<planning::constraint::TumorPlan> > tumorPlans)
{
    for(auto it = layers->begin(); it != layers->end();)
    {
        if((*it).layerName.compare("trajectories") == 0)
        {
            it = layers->erase(it);
        }
        else
        {
            ++it;
        }
    }

    for(auto tumorPlan : *tumorPlans)
    {
        for(auto trajectory : *tumorPlan.trajectories)
        {
            layers->push_back(planning::layer::ImageLayer("trajectories", trajectory.polyData));
        }
    }
}

std::shared_ptr<std::vector<planning::layer::ImageLayer>> planning::layer::create_hard_constraint_layer(const std::shared_ptr<std::vector<planning::layer::ImageLayer>> layers)
{
    std::shared_ptr<std::vector<planning::layer::ImageLayer>> hard{new std::vector<planning::layer::ImageLayer>};

    for(auto layer : *layers)
    {
        if(layer.layerName.compare("centroid") == 0 ||
                layer.layerName.compare("trajectories") == 0 ||
                layer.layerName.compare("mean_direction") == 0 ||
                layer.layerName.compare("mean_direction_2") == 0 ||
                layer.layerName.compare("liver") == 0 ||
                layer.layerName.compare("skin") == 0 ||
                layer.layerName.compare("livertumor") == 0) continue;
        hard->push_back(ImageLayer("hard", layer.polyData));
    }
    return consolidateLayers(hard);
}
