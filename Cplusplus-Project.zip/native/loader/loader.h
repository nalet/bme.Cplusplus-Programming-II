#ifndef LOADER_H
#define LOADER_H

#include <QUrl>
#include <QDebug>
#include <vector>
#include <filesystem>
#include <vtkPolyData.h>
#include <vtkPolyDataReader.h>
#include <vtkSmartPointer.h>
#include <string>
#include <algorithm>

namespace loader
{

class PatientData
{
public:
    std::filesystem::path patient{};
    std::filesystem::path segementation{};
    std::vector<std::filesystem::path> vtk{};
};

std::shared_ptr<PatientData> load(QUrl path);
vtkSmartPointer<vtkPolyData> read_poly_data(std::filesystem::path path);

}

#endif // LOADER_H
