#ifndef LAYER_H
#define LAYER_H

#include <string>
#include <vtkPolyData.h>
#include <vtkSmartPointer.h>
#include "loader/loader.h"
#include "vtkAppendPolyData.h"
#include "vtkSmartPointer.h"
#include "vtkPolyDataMapper.h"
#include "vtkPoints.h"
#include "vtkCellArray.h"
#include <array>
#include "planning/constraint.h"

namespace planning::constraint
{
class TumorPlan;
}

namespace planning::layer
{
class ImageLayer
{
public:
    ImageLayer(std::string layerName, vtkSmartPointer<vtkPolyData> polyData);
    std::string layerName;
    vtkSmartPointer<vtkPolyData> polyData;
};

std::shared_ptr<std::vector<planning::layer::ImageLayer>> consolidateLayers(const std::shared_ptr<std::vector<planning::layer::ImageLayer>> layers);
std::shared_ptr<std::vector<planning::layer::ImageLayer>> prepareLayers(std::vector<std::filesystem::path> layerFiles);
vtkSmartPointer<vtkPolyData> createPointsLayer(std::vector<std::array<float, 3>> pointList);
ImageLayer createLayer(vtkSmartPointer<vtkPolyData> polyData, std::string layer_name);
void updateLayerWithTrajectories(const std::shared_ptr<std::vector<planning::layer::ImageLayer>> layers, std::shared_ptr<std::vector<planning::constraint::TumorPlan>> tumorPlans);
std::shared_ptr<std::vector<planning::layer::ImageLayer>> create_hard_constraint_layer(const std::shared_ptr<std::vector<planning::layer::ImageLayer>> layers);

}
#endif // LAYER_H
